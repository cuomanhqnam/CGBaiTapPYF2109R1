from turtle import*
turtle = Turtle()
turtle.pensize(5)
turtle.pencolor("Red")
turtle.fillcolor("Blue")
turtle.begin_fill()
turtle.circle(100)
turtle.end_fill()
Turtle.done()