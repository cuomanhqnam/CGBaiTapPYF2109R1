# Bước 1: Import thư viện Turtle
from turtle import *

#Bước 2: Khởi tạo
turtle = Turtle()

# Bước 3: Thực hiện vẽ về phía trước 100 Pixel
turtle.forward(100)
turtle.done()



